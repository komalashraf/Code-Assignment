Code Assignment
===

** version 1.0.0

Documet sample to run code

## License & Copyright

Komal Ashraf Java Developer

 This project is developed using Spring Boot Framework.

@How to run Project in Eclipse

1. Click Help ->  Eclipse marketspace
2. Search "Spring tool suite" 
3. Click  install for "Spring tool suite" and Click Finish.
4. File Import -> Existing Maven Project
5. Click Next -> Select root directory and click Finish
6. 